This font is made by Typesgal and is free for both personal and commercial usage.

Donations are welcome and much appreciated (typesgal@gmail.com)!

For more information you can contact here: typesgal@gmail.com